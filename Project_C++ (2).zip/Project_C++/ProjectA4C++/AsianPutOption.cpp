#include "AsianPutOption.h"

AsianPutOption::AsianPutOption(std::vector<double> TimeSteps, double strike_) : AsianOption(TimeSteps), strike_(strike_) {
	if (strike_ <= 0) {
		throw std::out_of_range("incorrect value for _strike");
	}
}



double AsianPutOption::payoff(double z)
{
	if (strike_ >= z)
		return (strike_ - z);
	return 0;
}