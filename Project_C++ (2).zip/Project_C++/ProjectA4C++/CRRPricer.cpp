#include "CRRPricer.h"


CRRPricer::CRRPricer(Option* option, int depth, double asset_price, double Up, double Down, double interest_rate) :option(option), depth(depth), asset_price(asset_price), Up(Up), Down(Down), interest_rate(interest_rate)
{
        if ((*option).isAsianOption()) {
            throw std::out_of_range("Error: Asian Option");
        }
        else if (asset_price >= 0)
        {

            if (Down > interest_rate || interest_rate > Up) // The model admits no arbitrage iif D < R < U.
            {
                std::cout << "arbitrage!" << std::endl;
            }
            else
            {
                if (Up > Down && Down > -1)
                {
                    _tree.setDepth(depth);
                    if ((*option).isAmericanOption() == true) {
                        _treeAOption.setDepth(depth);
                    }
                }
                else
                {
                    std::cout << "Error with the condition U>D>-1" << std::endl;
                }
            }
        }
        else
        {
            std::cout << "Error with the condition S < 0" << std::endl;
        }
    
    
    
}


// TD8
CRRPricer::CRRPricer(Option* option, int depth, double asset_price, double r, double sigma) : option(option), depth(depth), asset_price(asset_price)
{
    //innitialisation comme en section 2
    
    double h = (*option).getExpiry() / depth;
    Up = exp((r + (sigma * sigma) / 2)*h+ sigma *sqrt(h))-1;
    Down = exp((r + (sigma * sigma) / 2) * h - sigma * sqrt(h))-1;
    interest_rate = exp(r * h) - 1;

    //same methode as above
    if ((*option).isAsianOption()) { //Asian Option?
        throw std::out_of_range("Error: Asian Option");
    }
    else if (asset_price >= 0)
    {

        if (Down > interest_rate || interest_rate > Up) //Respect of condition?
        {
            std::cout << "arbitrage!" << std::endl;
        }
        else
        {
            if (Up > Down && Down > -1)//Respect of condition?
            {
                _tree.setDepth(depth);
                if ((*option).isAmericanOption() == true) {
                    _treeAOption.setDepth(depth);
                }
            }
            else
            {
                std::cout << "Error with the condition U>D>-1" << std::endl;
            }
        }
    }
    else
    {
        std::cout << "Error with the condition S < 0" << std::endl;
    }



}

void CRRPricer::compute()
{
    double q = (interest_rate - Down) / (Up - Down); //formula

    for (int i = 0; i <= depth; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            _tree.setNode(i, j, asset_price * pow(1 + Up, j) * pow(1 + Down, i - j)); //formula : S(n,i) = S*(1+U)^i*(1+D)^(n-i)
        }
    }


    //payoffs of the last step
    for (int i = 0; i <= depth; i++)
    {
        _tree.setNode(depth, i, (*option).payoff(_tree.getNode(depth, i)));
        if ((*option).isAmericanOption()) {
            _treeAOption.setNode(depth, i, true);
        }
    }
    
    for (int i = depth - 1; i >= 0; i--)
    {
        for (int j = 0; j <= i; j++)
        {
            if ((*option).isAmericanOption())
                {
                double a = (*option).payoff(_tree.getNode(i, j));
                double b = (q * _tree.getNode(i + 1, j + 1) + (1 - q) * _tree.getNode(i + 1, j)) / (1 + interest_rate);//formula
                if (a >= b)
                    {
                        _tree.setNode(i, j, a);
                        _treeAOption.setNode(i, j, true);
                    }
                else
                    {
                        _tree.setNode(i, j, b);
                        _treeAOption.setNode(i, j, false);
                    }
                }
            else
            {
                _tree.setNode(i, j, (q * _tree.getNode(i + 1, j + 1) + (1 - q) * _tree.getNode(i + 1, j)) / (1 + interest_rate));
            }
            
        }
    }
}



double CRRPricer::get(int i, int j)
{
    return _tree.getNode(i, j);
}


bool CRRPricer::getExercise(int step, int node)
{
    return _treeAOption.getNode(step, node);
}

double factoriel(int n)
{
    double result = 1;
    if (n == 0) {
        return 1;
    }
    else
    {
        for (int i = 1; i <= n; i++) {
            result = result * i;
        }
    }
    return result;
}


double CRRPricer::operator()(bool closed_form)
{
    double price = 0;

    compute();

    if (closed_form == true)
    {
        double sum = 0;
        double q = (interest_rate - Down) / (Up - Down); // risk-neutral probability
        for (int i = 0; i <= depth; i++)
        {
            sum += (factoriel(depth) / (factoriel(i) * factoriel(depth - i))) * pow(q, i) * pow(1 - q, depth - i) * get(depth, i);
        }
        price = (sum / pow((1 + interest_rate), depth));
    }
    else
    {
        price = get(0, 0);
    }

    return price;
}