#pragma once
#include "Option.h"
#include "BinaryTree.h"
class CRRPricer
{
public:
	CRRPricer(Option* option, int depth, double asset_price, double Up, double Down, double interest_rate);
	CRRPricer(Option* option, int depth, double asset_price, double r, double sigma);
	void compute();
	double get(int step, int node);
	bool getExercise(int step, int node);
	double operator()(bool closed_form = false);
private:
	Option* option;
	int depth;
	double asset_price;
	double Up;
	double Down;
	double interest_rate;
	BinaryTree <double> _tree;
	BinaryTree <bool> _treeAOption;
	
};