#pragma once
#include "Option.h"
#include "MT.h"
class BlackScholesMCPricer {
public:
	BlackScholesMCPricer(Option* option, double initial_price, double interest_rate, double volatility);
	int getNbPaths();
	void generate(int nb_paths);
	double operator()();
	std::vector<double> confidenceInterval();
	
private:
	Option* option;
	double initial_price;
	double interest_rate;
	double volatility;
	double numberPaths;
	double meanPayOff;
	double currentEstimate;
	std::vector<std::vector<double>> vecteurPrixTk;
};
