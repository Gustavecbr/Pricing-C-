#pragma once
#include <random>
#include <iostream>

class Option
{
public:
	Option();
	Option(double _expiry);
	double getExpiry();
	virtual double payoff(double) = 0;
	virtual double payoffPath(std::vector<double>);
	virtual bool isAsianOption();
	virtual bool isAmericanOption();
	friend class BlackScholesPricer;
private:

	double _expiry;

};

