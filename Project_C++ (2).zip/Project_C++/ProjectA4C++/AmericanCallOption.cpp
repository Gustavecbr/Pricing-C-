#include "AmericanCallOption.h"

AmericanCallOption::AmericanCallOption(double _expiry, double _strike) : AmericanOption(_expiry, _strike) {  }

double AmericanCallOption::payoff(double z)
{
	if (z >= _strike)
		return z - _strike;
	return 0;
}
