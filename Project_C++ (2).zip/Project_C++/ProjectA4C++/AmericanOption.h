#pragma once
#include <iostream>
#include "Option.h"

class AmericanOption : public Option
{
public:
	AmericanOption(double _expiry, double _strike);
	bool isAmericanOption() override;
	friend class AmericanCallOption;
	friend class AmericanPutOption;
private:
	double _strike;

};