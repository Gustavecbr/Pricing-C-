#include "BlackScholesPricer.h"
# define M_PI           3.14159265358979323846  /* pi */
BlackScholesPricer::BlackScholesPricer(VanillaOption* option, double asset_price, double interest_rate, double volatility) :
	option(option), asset_price(asset_price), interest_rate(interest_rate), volatility(volatility) {
	optionDigital = 0;
}

BlackScholesPricer::BlackScholesPricer(DigitalOption* optionDigital, double asset_price, double interest_rate, double volatility) :
	optionDigital(optionDigital), asset_price(asset_price), interest_rate(interest_rate), volatility(volatility) {
	option = 0;
}



double N(double z)//Cumulative Normal approximation here.  I pulled this thing off the net.
{
	const double b1 = 0.319381530;
	const double b2 = -0.356563782;
	const double b3 = 1.781477937;
	const double b4 = -1.821255978;
	const double b5 = 1.330274429;
	const double p = 0.2316419;
	const double c2 = 0.39894228;

	double a = fabs(z);
	double t = 1.0 / (1.0 + a * p);
	double b = c2 * exp((-z) * (z / 2.0));
	double n = ((((b5 * t + b4) * t + b3) * t + b2) * t + b1) * t;

	n = 1 - b * n;
	if (z < 0) n = 1 - n;
	return n;
}



double BlackScholesPricer::operator()() {
	double d1;
	double d2;
	double result;
	if (optionDigital == 0)
	{
		d1 = (log(asset_price / (*option)._strike) + (*option)._expiry * (interest_rate + pow(volatility, 2) / 2)) / (volatility * sqrt((*option)._expiry));
		d2 = d1 - volatility * sqrt((*option)._expiry);
		if ((*option).GetOptionType() == OptionType::call) {






			result = asset_price * N(d1) - (*option)._strike * exp(-interest_rate * (*option)._expiry) * N(d2);



		}
		else {





			result = -asset_price * N(-d1) + (*option)._strike * exp(-interest_rate * (*option)._expiry) * N(-d2);


		}

	}
	else
	{
		d1 = (log(asset_price / (*optionDigital)._strike) + (*optionDigital)._expiry * (interest_rate + pow(volatility, 2) / 2)) / (volatility * sqrt((*optionDigital)._expiry));
		d2 = d1 - volatility * sqrt((*optionDigital)._expiry);
		if ((*optionDigital).GetDigitalOptionType() == DigitalOptionType::DigitalCall) {






			result = exp(-interest_rate * (*optionDigital)._expiry) * N(d2);


		}
		else {




			result = exp(-interest_rate * (*optionDigital)._expiry) * N(-d2);

		}

	}

	return result;
}

double BlackScholesPricer::delta() {

	double d1;
	double delta;


	if (optionDigital == 0)
	{
		d1 = (log(asset_price / (*option)._strike) + (*option)._expiry * (interest_rate + pow(volatility, 2) / 2)) / (volatility * sqrt((*option)._expiry));
		if ((*option).GetOptionType() == OptionType::call) {
			delta = N(d1);


		}
		else {

			delta = N(d1) - 1;


		}

	}

	else
	{

		d1 = (log(asset_price / (*optionDigital)._strike) + (*optionDigital)._expiry * (interest_rate + pow(volatility, 2) / 2)) / (volatility * sqrt((*optionDigital)._expiry));
		double normDensite = (1 / (std::sqrt(2 * M_PI))) * exp(-0.5 * std::pow(d1, 2));
		double gamma = normDensite / (asset_price * volatility * std::sqrt((*optionDigital)._expiry));
		if ((*optionDigital).GetDigitalOptionType() == DigitalOptionType::DigitalCall) {
			delta = gamma * asset_price / (*optionDigital)._strike;


		}
		else {

			delta = -gamma * asset_price / (*optionDigital)._strike;


		}
	}



	return delta;
}
