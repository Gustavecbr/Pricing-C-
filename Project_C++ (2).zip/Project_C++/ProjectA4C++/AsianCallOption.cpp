#include "AsianCallOption.h"

AsianCallOption::AsianCallOption(std::vector<double> TimeSteps, double strike_) : AsianOption(TimeSteps), strike_(strike_) {
	if (strike_ <= 0) {
		throw std::out_of_range("incorrect value for _strike");
	}
}



double AsianCallOption::payoff(double z)
{
	if (z >= strike_) {
		return  z - strike_;
	}
	return 0;

}