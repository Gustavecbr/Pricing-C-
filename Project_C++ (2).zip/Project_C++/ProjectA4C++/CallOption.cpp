#include "CallOption.h"

CallOption::CallOption( double _expiry, double _strike): VanillaOption(_expiry, _strike){}


double CallOption::payoff(double a)  {
	if (a>= _strike ) {
		return  a -_strike ;
	}
	return 0;
}

OptionType CallOption::GetOptionType() {
	 
	return OptionType::call;
}