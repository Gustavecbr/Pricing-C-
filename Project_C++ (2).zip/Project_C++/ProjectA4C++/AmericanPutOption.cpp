#include "AmericanPutOption.h"


AmericanPutOption::AmericanPutOption(double _expiry, double _strike) : AmericanOption(_expiry, _strike) {}

double AmericanPutOption::payoff(double z)
{
	if (_strike >= z)
		return _strike - z;
	return 0;
}
