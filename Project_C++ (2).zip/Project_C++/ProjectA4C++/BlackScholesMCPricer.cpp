
#include "BlackScholesMCPricer.h"
#include "AsianOption.h"
#include "MT.h"

BlackScholesMCPricer::BlackScholesMCPricer(Option* option, double initial_price, double interest_rate, double volatility) :
	option(option), initial_price(initial_price), interest_rate(interest_rate), volatility(volatility)
{
	numberPaths = 0;
    meanPayOff = 0;
    currentEstimate=0;
}

int BlackScholesMCPricer::getNbPaths() {
	return numberPaths;
}



void BlackScholesMCPricer::generate(int numb_paths) {

    double expiry = 0;
    double T = 0;
    double m = 0;

    if ((*option).isAsianOption()) {
        AsianOption* asianOption = (AsianOption*)option;
        std::vector<double> timeSteps = (*asianOption).getTimeSteps();
        m = timeSteps.size();
        expiry = timeSteps.back();
        T = expiry / m;
    }
    else
    {
        
        T =(*option).getExpiry();
        m = 1;
    }

    vecteurPrixTk.resize(numb_paths);

    for (int i = 0; i < numb_paths; i++) {
        vecteurPrixTk[i].resize(m + 1);
    }


    for (int i = 0; i < numb_paths; i++) {
        vecteurPrixTk[i][0] = initial_price;
    }

    double N = 0;
    for (int i = 0; i < numb_paths; i++) {
        for (int j = 1; j <= m; j++) {
            std::random_device rd;
            std::mt19937 gen(rd());
            N = MT::rand_norm(gen);
            vecteurPrixTk[i][j] = vecteurPrixTk[i][j - 1]*exp(((interest_rate - ((volatility * volatility) / 2)) * T) + (volatility * sqrt(T) * N));
        }
        
        
        currentEstimate= (numberPaths * currentEstimate + (*option).payoffPath(vecteurPrixTk[i])) / (numberPaths + 1);
        
        numberPaths += 1;
    }

    meanPayOff = currentEstimate;
}



double BlackScholesMCPricer::operator()() {
    
    if (numberPaths== 0)
    {
        throw std::string("ERROR !");
            
    }
    else
    {
        if ((*option).isAsianOption()) 
        {
            AsianOption* asianOption = (AsianOption*)option;
            std::vector<double> timeSteps = (*asianOption).getTimeSteps();
            return exp(-interest_rate * timeSteps.back()) * currentEstimate;   
        }
        else
        {
            return exp(-interest_rate * (*option).getExpiry()) * currentEstimate;
        }
    }
}

    


std::vector<double> BlackScholesMCPricer::confidenceInterval() {
    double lower_bound = 0;
    double upper_bound = 0;
    if (numberPaths == 0) {
        throw std::string("ERROR !");
    }
    else {
        if ((*option).isAsianOption()) {
            std::vector<double> CI;
            CI.push_back(currentEstimate - 1.96 * (volatility / pow(BlackScholesMCPricer::getNbPaths(), 0.5)));
            CI.push_back(currentEstimate + 1.96 * (volatility / pow(BlackScholesMCPricer::getNbPaths(), 0.5)));
            return CI;
        }
        else {
            std::vector<double> CI;
            CI.push_back(volatility - (volatility / pow(BlackScholesMCPricer::getNbPaths(), 0.5)));
            CI.push_back(volatility + (volatility / pow(BlackScholesMCPricer::getNbPaths(), 0.5)));
            return CI;
        }
    }
}


