#include <iostream>
#include "AsianOption.h"
#include <string>
#pragma once

class AsianPutOption : public AsianOption
{
public:
	AsianPutOption(std::vector<double> TimeSteps, double strike_);
	double payoff(double);

	
private:
	std::vector<double> TimeSteps;
	double strike_;
};

