#include <iostream>
#include "Option.h"
#include <string>

Option::Option() { _expiry = 0; }

Option::Option(double _expiry) : _expiry(_expiry){
	if (_expiry < 0) {
		throw std::out_of_range("incorrect value for _expiry");
	}
}

bool Option::isAsianOption() {
	return false;
}

double Option::getExpiry() {
	return _expiry;
}

bool Option::isAmericanOption() {
	return false;
}

double Option::payoffPath(std::vector<double> Prix) 
{
	return payoff(Prix.back());
}