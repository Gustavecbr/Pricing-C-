#pragma once
#include <iostream>
#include "AsianOption.h"
#include <string>


class AsianCallOption : public AsianOption
{
public:
	AsianCallOption(std::vector<double> TimeSteps, double strike_);
	double payoff(double) ;


private:
	std::vector<double> TimeSteps;
	double strike_;
};

