#pragma once
#include <iostream>
#include <vector>

template<class T> class BinaryTree
{
public:
	
	void setDepth(int a) {
		_depth = a;
		_tree.resize(_depth + 1); // ON SET LE NOMBRE DE NOEUD � 1
		for (int i = 0; i <= _depth; i++) {
			_tree[i].resize(i + 1);//on augmente de 1 chaque �l�ment du vecteur

		}
	}


	void setNode(int i, int j, T a){

		_tree[i][j] = a;

	
	}


	T getNode(int i, int j){

		return _tree[i][j];

	}

	
	void display(){
		int i = 0;
		int j = 0;

		while (i <= 2 * _depth)
		{
			for (int k = 0; k <= (4 * _depth - i); k++) {
				std::cout << " ";
			}

			if (i % 2 == 1)
			{
				j = 0;
				while (j <= i)				
				{
					if (j % 2 == 1)
					{
						std::cout << "\\ "; // 1 seul back slash ne fonctionne pas sur c++, on va � droite
					}
					else 
					{
						std::cout << "/ "; // on va � gauche
					}
					j = j + 1;
				}
			}

			else
			{
				for (int j = 0; j <= i / 2; j++)
				{
					std::cout << _tree[i / 2][j];

					if (i > 0) 
					{ 
						std::cout << "   "; 
					}
				}
			}
			std::cout << "\n";
			i = i + 1;
		}
	}


private:
	int _depth=0;
	std::vector<std::vector<T>> _tree;
};

