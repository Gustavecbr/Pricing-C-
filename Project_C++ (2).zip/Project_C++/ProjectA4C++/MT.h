#pragma once

#include <random>

class MT
{
public:
	MT();
	static std::mt19937 random;
	static double rand_unif(std::mt19937);
	static double rand_norm(std::mt19937);

private:
	
};