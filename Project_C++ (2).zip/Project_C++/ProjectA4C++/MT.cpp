#include "MT.h"

MT::MT() {};

double MT::rand_unif(std::mt19937 random) {
	std::uniform_real_distribution<double> uniform_dis(0.0, 1.0);
	return uniform_dis(random);
}


double MT::rand_norm(std::mt19937 random)
{
	std::normal_distribution<double> normal_dis(0.0, 1.0);
	return normal_dis(random);
}
