#include "PutOption.h"

PutOption::PutOption( double _expiry, double _strike) : VanillaOption(_expiry, _strike) {}


double PutOption::payoff(double a) {
	if (_strike >= a) {
		return  _strike -a;
	}
	return 0;

}

OptionType PutOption::GetOptionType() {
	
	return OptionType::put;
}