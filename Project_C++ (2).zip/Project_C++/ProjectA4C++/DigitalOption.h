#pragma once
#include "Option.h"

enum class DigitalOptionType { DigitalCall, DigitalPut };

class DigitalOption : public Option
{
public:
	DigitalOption(double _expiry, double _strike);
	
	virtual DigitalOptionType GetDigitalOptionType() = 0;
	friend class BlackScholesPricer;
	friend class DigitalPutOption;
	friend class DigitalCallOption;
private:
	double _strike;
};
