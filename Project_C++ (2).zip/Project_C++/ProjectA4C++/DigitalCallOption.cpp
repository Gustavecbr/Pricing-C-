#include "DigitalCallOption.h"

DigitalCallOption::DigitalCallOption(double _expiry, double _strike) : DigitalOption(_expiry, _strike) {}


double DigitalCallOption::payoff(double a)
{
	
	if (a >= _strike)
		return 1;
	return 0;
}
DigitalOptionType DigitalCallOption::GetDigitalOptionType()
{
	return DigitalOptionType::DigitalCall;
}