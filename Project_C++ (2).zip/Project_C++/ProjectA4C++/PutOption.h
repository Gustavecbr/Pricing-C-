#pragma once
#include "VanillaOption.h"

class PutOption : public VanillaOption
{
public:
	PutOption(double _expiry, double _strike);

	double payoff(double a);

	OptionType GetOptionType() override;
private:
};