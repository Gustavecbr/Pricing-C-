#include <iostream>

#include <string>
#include "AsianOption.h"




AsianOption::AsianOption(std::vector<double> TimeSteps) : TimeSteps(TimeSteps){}

std::vector<double> AsianOption::getTimeSteps() {
	return TimeSteps;
}

bool AsianOption::isAsianOption() {
	return true;
}

double AsianOption::payoffPath(std::vector<double> Price) {
	double k = 0;
	for (int i = 0;i < Price.size() - 1; i++)
	{
		k = Price[i] + k;
	}
	k = k / (Price.size() - 1);
	k = payoff(k);
	return k;
}


