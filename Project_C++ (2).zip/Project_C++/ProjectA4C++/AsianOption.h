#pragma once
#include <iostream>
#include "Option.h"
#include <string>


class AsianOption : public Option
{
public:
	AsianOption(std::vector<double> TimeSteps);
	std::vector<double> getTimeSteps();
	bool isAsianOption() override;
	double payoffPath(std::vector<double> Price) override;
private:
	std::vector<double> TimeSteps;
	
};
