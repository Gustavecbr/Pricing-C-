#pragma once
#include <random>
#include <iostream>
#include "Option.h"
#
enum class OptionType
{
	call, put
};

class VanillaOption: public Option
{
public:
	VanillaOption(double _expiry, double _strike);
	
	virtual OptionType GetOptionType()=0;
	friend class BlackScholesPricer ;
	friend class CallOption;
	friend class PutOption;
private:
	double _strike;
	
};

