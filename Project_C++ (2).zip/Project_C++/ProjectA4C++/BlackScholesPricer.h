#pragma once
#include "VanillaOption.h"
#include "DigitalOption.h"

class BlackScholesPricer
{
public:
	BlackScholesPricer(VanillaOption* option, double asset_price, double interest_rate, double volatility);
	BlackScholesPricer(DigitalOption* option, double asset_price, double interest_rate, double volatility);
	double operator()();
	double delta();
private:
	VanillaOption* option;
	DigitalOption* optionDigital;
	double asset_price;
	double interest_rate;
	double volatility;
	
};
