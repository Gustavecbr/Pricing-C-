#pragma once
#include <iostream>
#include "DigitalOption.h"

class DigitalCallOption : public DigitalOption
{
public:
	DigitalCallOption(double _expiry, double _strike);

	double payoff(double);
	DigitalOptionType GetDigitalOptionType() override;
};