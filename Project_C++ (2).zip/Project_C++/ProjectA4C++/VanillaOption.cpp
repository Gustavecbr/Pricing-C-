#include <iostream>
#include "Option.h"
#include <string>
#include "VanillaOption.h"

VanillaOption::VanillaOption(double  _expiry, double _strike) :Option(_expiry), _strike(_strike) {
	if (_strike < 0) {
		throw std::out_of_range("incorrect value for _strike");
	}

}

