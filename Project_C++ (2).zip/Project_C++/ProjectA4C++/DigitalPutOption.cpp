#include "DigitalPutOption.h"

DigitalPutOption::DigitalPutOption(double _expiry, double _strike) : DigitalOption(_expiry,_strike ) {}


double DigitalPutOption::payoff(double z)
{
	double profit = 0;
	if (z <= _strike)
		profit = 1;
	return profit;
}

DigitalOptionType DigitalPutOption::GetDigitalOptionType() {
	return DigitalOptionType::DigitalPut;
}