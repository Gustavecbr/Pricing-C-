#include "DigitalOption.h"
#include "Option.h"

DigitalOption::DigitalOption(double _expiry, double _strike) :Option(_expiry), _strike(_strike) {
	if (_strike <= 0)
		throw std::out_of_range("incorrect value for _strike");

}


